from time import strftime

hour = strftime("%H")
minute = strftime("%M")
seconds = strftime("%S")

msg_send('&fBot: &2Godzin: &f'+hour+' &2Minut: &f'+minute+' &2Sekund: &f'+seconds)
