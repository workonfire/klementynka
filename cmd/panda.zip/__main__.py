msg_send('&fBot: &8Panda &fpozdrawia!')
