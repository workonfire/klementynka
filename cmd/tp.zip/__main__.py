msg_send('/tpahere '+user_nick)
msg_send('/msg '+user_nick+' Wyslano prosbe o teleportacje, na zyczenie. Zaakceptuj.')