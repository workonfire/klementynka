from random import randrange

liczba = randrange(0, 1)
if(liczba == 0):
	msg_send('&fBot: &2Moneta wypadla na reszke!')
if(liczba == 1):
	msg_send('&fBot: &2Moneta wypadla na orla!')
