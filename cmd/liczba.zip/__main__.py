from random import randrange

msg_send('&fBot: &2Twoja szczesliwa liczba na dzis to &f'+str(randrange(1, 100)))
