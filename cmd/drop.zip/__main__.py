msg_send('&fBot: &2Wlasnie wyrzucilem to, co mialem w rece.')
press('q')
