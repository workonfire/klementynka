msg_send('/is expell '+target_nick)
msg_send('/msg '+target_nick+' Zostales wyrzucony z groty, na zyczenie.')
