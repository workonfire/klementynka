import urllib2

def status(numer):
	if numer == "":
		msg_send('&fBot: &2Blad: &7Wprowadz numer GG.')
	try:
		status = urllib2.urlopen("http://status.gadu-gadu.pl/users/status.asp?id="+str(numer.rstrip())+"&styl=6").read()
	except urllib2.HTTPError:
		msg_send('&fBot: &2Przykro mi, wystapil blad :c')
	if(status == "unavailable\n"):
		msg_send('&fBot: &2Status numeru GG &f'+numer.rstrip()+' &2to &fniedostepny')
	if(status == "dnd\n"):
		msg_send('&fBot: &2Status numeru GG &f'+numer.rstrip()+' &2to &fnie przeszkadzac')
	if(status == "busy\n"):
		msg_send('&fBot: &2Status numeru GG &f'+numer.rstrip()+' &2to &fzaraz wracam')
	if(status == "talktome\n"):
		msg_send('&fBot: &2Status numeru GG &f'+numer.rstrip()+' &2to &fpogadam')
	if(status == "available\n"):
		msg_send('&fBot: &2Status numeru GG &f'+numer.rstrip()+' &2to &fdostepny')
		
status(target_nick)
