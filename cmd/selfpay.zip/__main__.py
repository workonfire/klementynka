x = user_msg.split(' ')
password = 'klementynka29'
if x[1] == '[':
	try:
		ile = x[7]
		haslo = x[-1]
	except IndexError:
		pass
	if haslo == password+'\n':
		msg_send('/r Haslo poprawne!')
		if int(ile) > 1000: # Opcjonalne ograniczenie
			msg_send('/r Pieniadze nie zostaly przelane, maksymalna wartosc to 100$.')
		else:
			msg_send('/pay '+target_nick+' '+ile)
	else:
		msg_send('/r Haslo niepoprawne!')
else:
	pass
