from random import randrange
typewrite('t')
hotkey('ctrl', 'a')
hotkey('backspace')
typewrite('&fBot: &2Wylosowana osoba to&f ')
for i in range(1, randrange(1, 50)):
	press('tab')
hotkey('enter')
