for i in range(1, 9):
	msg_send('&fBot: &2Trwa wyrzucanie bota z servera, poczekaj...')
