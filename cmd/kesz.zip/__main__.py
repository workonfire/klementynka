from random import randrange

kesz = str(randrange(1, 500))
msg_send('/pay '+target_nick+' '+kesz)
msg_send('&fBot: '+target_nick+' &2wlasnie dostal &f'+kesz+'&2$!')
msg_send('/msg '+target_nick+' Prosze bardzo, to dla Ciebie!')
