msg_send('&fBot: &2Bi&ag&fo&as&2io &djest &fk&6o&el&ao&2r&3o&1w&5y')
